
from django.urls import path
from . import views

urlpatterns = [
    path("csrf/", views.obter_csrf),
    path("login/", views.login_usuario),
    path("logout/", views.logout_usuario),
    path("usuario/", views.consultar_usuario),
    path("torneios/", views.listar_torneios),
    path("torneios/cadastrar/", views.cadastrar_torneio),
    path("torneios/atualizar/<int:torneio_id>/", views.atualizar_torneio),
    path("jogadores/cadastrar/", views.cadastrar_jogador),
    path("jogadores/meu-perfil/", views.consultar_meu_jogador),
    path("inscricoes/cadastrar/", views.inscrever_jogador),
    path("inscricoes/<int:torneio_id>/", views.listar_inscricoes),
    path("partidas/sortear/", views.sortear_confrontos),
    path("partidas/avancar-fase/", views.avancar_fase),
    path("partidas/gerar-final/", views.gerar_final),
    path("partidas/cadastrar/", views.criar_partida),
    path("partidas/<int:torneio_id>/", views.listar_partidas),
    path("partidas/detalhes/<int:partida_id>/", views.consultar_partida),
    path("partidas/resultado/<int:partida_id>/", views.registrar_resultado),
    path("torneios/detalhes/<int:torneio_id>/", views.consultar_torneio),
    path("torneios/classificacao/<int:torneio_id>/", views.consultar_classificacao),
]
