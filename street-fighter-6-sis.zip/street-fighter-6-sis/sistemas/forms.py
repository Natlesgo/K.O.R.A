
from django import forms


class TorneioForm(forms.Form):
    nome = forms.CharField(max_length=45)
    codigo = forms.CharField(max_length=45)


class JogadorForm(forms.Form):
    nome = forms.CharField(max_length=45)
    nick = forms.CharField(max_length=45)
    email = forms.CharField(max_length=45)
    senha = forms.CharField()


class PartidaForm(forms.Form):
    torneio_id = forms.IntegerField(min_value=1)
    jogador1_id = forms.IntegerField(min_value=1)
    jogador2_id = forms.IntegerField(min_value=1)
    fase = forms.ChoiceField(choices=[
        ("Quartas de final", "Quartas de final"),
        ("Semifinal", "Semifinal"),
        ("Final", "Final")
    ])
