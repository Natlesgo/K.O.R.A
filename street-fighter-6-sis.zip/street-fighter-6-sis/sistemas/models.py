from django.db import models

class Torneio(models.Model):
    nome = models.CharField(max_length=45)
    codigo = models.CharField(max_length=45)

    def __str__(self):
        return self.nome

class Jogadores(models.Model):
    nome = models.CharField(max_length=45)
    nick = models.CharField(max_length=45)
    email = models.CharField(max_length=45)

    def __str__(self):
        return self.nick

class Usuarios(models.Model):
    login = models.CharField(max_length=45)
    senha = models.CharField(max_length=45)
    papel = models.CharField(max_length=45)

    def __str__(self):
        return self.login

class TorneioJogadores(models.Model):
    torneio = models.ForeignKey(Torneio, on_delete=models.CASCADE)
    jogador = models.ForeignKey(Jogadores, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.id)

class Partida(models.Model):
    fase = models.CharField(max_length=45)
    torneio = models.ForeignKey(Torneio, on_delete=models.CASCADE)
    usuario = models.ForeignKey(Usuarios, on_delete=models.CASCADE)

    def __str__(self):
        return self.fase


class PartidaParticipante(models.Model):
    torneio = models.ForeignKey(Torneio, on_delete=models.CASCADE)
    jogador = models.ForeignKey(Jogadores, on_delete=models.CASCADE)
    partida = models.ForeignKey(Partida, on_delete=models.CASCADE)
    vitoria = models.BooleanField(default=False)

    def __str__(self):
        return str(self.id)