
from django.test import TestCase, Client
from django.contrib.auth.models import User, Group
from .models import Torneio, Jogadores, Usuarios, TorneioJogadores, Partida, PartidaParticipante


class TestesBackend(TestCase):

    @classmethod
    def setUpTestData(cls):
        cls.grupo_organizador = Group.objects.create(name="organizador")
        cls.grupo_juiz = Group.objects.create(name="juiz")
        cls.grupo_jogador = Group.objects.create(name="jogador")

        cls.organizador = User.objects.create_user(
            username="organizador", password="SenhaTeste@2026"
        )
        cls.organizador.groups.add(cls.grupo_organizador)

        cls.juiz = User.objects.create_user(
            username="juiz", password="SenhaTeste@2026"
        )
        cls.juiz.groups.add(cls.grupo_juiz)

        cls.conta_jogador = User.objects.create_user(
            username="jogador@teste.com",
            email="jogador@teste.com",
            password="SenhaTeste@2026"
        )
        cls.conta_jogador.groups.add(cls.grupo_jogador)

        cls.usuario_organizador = Usuarios.objects.create(
            login="organizador", senha="", papel="organizador"
        )

        cls.torneio = Torneio.objects.create(
            nome="Campeonato Teste", codigo="TESTE001"
        )

        cls.jogador1 = Jogadores.objects.create(
            nome="Jogador Um", nick="Player1", email="jogador@teste.com"
        )
        cls.jogador2 = Jogadores.objects.create(
            nome="Jogador Dois", nick="Player2", email="player2@teste.com"
        )

        TorneioJogadores.objects.create(
            torneio=cls.torneio, jogador=cls.jogador2
        )

    def setUp(self):
        self.client = Client()

    def criar_jogadores_para_torneio(self, quantidade):
        TorneioJogadores.objects.filter(torneio=self.torneio).delete()
        jogadores = []

        for numero in range(1, quantidade + 1):
            jogador = Jogadores.objects.create(
                nome=f"Participante {numero}",
                nick=f"Competidor{numero}",
                email=f"competidor{numero}@teste.com"
            )
            TorneioJogadores.objects.create(
                torneio=self.torneio, jogador=jogador
            )
            jogadores.append(jogador)

        return jogadores

    def sortear(self):
        self.client.force_login(self.organizador)
        return self.client.post(
            "/api/partidas/sortear/",
            {"torneio_id": self.torneio.id},
            content_type="application/json"
        )

    def avancar(self):
        self.client.force_login(self.organizador)
        return self.client.post(
            "/api/partidas/avancar-fase/",
            {"torneio_id": self.torneio.id},
            content_type="application/json"
        )

    def registrar_vitorias_da_fase(self, fase):
        partidas = Partida.objects.filter(
            torneio=self.torneio, fase=fase
        ).order_by("id")

        vencedores = []
        self.client.force_login(self.juiz)

        for partida in partidas:
            participante = PartidaParticipante.objects.filter(
                partida=partida
            ).order_by("id").first()

            resposta = self.client.put(
                f"/api/partidas/resultado/{partida.id}/",
                {
                    "vencedor_id": participante.jogador_id,
                    "confirmado": True
                },
                content_type="application/json"
            )

            self.assertEqual(
                resposta.status_code, 200, resposta.content.decode()
            )
            vencedores.append(participante.jogador_id)

        return vencedores

    def criar_partida_manual(self, jogador1, jogador2, fase):
        self.client.force_login(self.organizador)
        return self.client.post(
            "/api/partidas/cadastrar/",
            {
                "torneio_id": self.torneio.id,
                "jogador1_id": jogador1.id,
                "jogador2_id": jogador2.id,
                "fase": fase
            },
            content_type="application/json"
        )

    def test_01_listar_torneios(self):
        resposta = self.client.get("/api/torneios/")
        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(
            resposta.json()["torneios"][0]["nome"], "Campeonato Teste"
        )

    def test_02_login_organizador(self):
        resposta = self.client.post(
            "/api/login/",
            {"login": "organizador", "senha": "SenhaTeste@2026"},
            content_type="application/json"
        )
        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(resposta.json()["usuario"], "organizador")

    def test_03_logout(self):
        self.client.force_login(self.organizador)
        resposta = self.client.post("/api/logout/")
        self.assertEqual(resposta.status_code, 200)

        consulta = self.client.get("/api/usuario/")
        self.assertEqual(consulta.status_code, 401)

    def test_04_jogador_nao_cria_torneio(self):
        self.client.force_login(self.conta_jogador)
        resposta = self.client.post(
            "/api/torneios/cadastrar/",
            {"nome": "Novo", "codigo": "NOVO001"},
            content_type="application/json"
        )
        self.assertEqual(resposta.status_code, 403)

    def test_05_organizador_cria_torneio(self):
        self.client.force_login(self.organizador)
        resposta = self.client.post(
            "/api/torneios/cadastrar/",
            {"nome": "Novo Torneio", "codigo": "NOVO001"},
            content_type="application/json"
        )
        self.assertEqual(resposta.status_code, 200)
        self.assertTrue(Torneio.objects.filter(codigo="NOVO001").exists())

    def test_06_perfil_jogador(self):
        self.client.force_login(self.conta_jogador)
        resposta = self.client.get("/api/jogadores/meu-perfil/")
        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(resposta.json()["nick"], "Player1")

    def test_07_inscricao_jogador(self):
        self.client.force_login(self.conta_jogador)
        resposta = self.client.post(
            "/api/inscricoes/cadastrar/",
            {"torneio_id": self.torneio.id},
            content_type="application/json"
        )
        self.assertEqual(resposta.status_code, 200)
        self.assertTrue(
            TorneioJogadores.objects.filter(
                torneio=self.torneio, jogador=self.jogador1
            ).exists()
        )

    def test_08_bloquear_inscricao_duplicada(self):
        TorneioJogadores.objects.create(
            torneio=self.torneio, jogador=self.jogador1
        )
        self.client.force_login(self.conta_jogador)
        resposta = self.client.post(
            "/api/inscricoes/cadastrar/",
            {"torneio_id": self.torneio.id},
            content_type="application/json"
        )
        self.assertEqual(resposta.status_code, 400)

    def test_09_juiz_nao_cria_torneio(self):
        self.client.force_login(self.juiz)
        resposta = self.client.post(
            "/api/torneios/cadastrar/",
            {"nome": "Teste", "codigo": "TESTE002"},
            content_type="application/json"
        )
        self.assertEqual(resposta.status_code, 403)

    def test_10_organizador_nao_registra_resultado(self):
        self.criar_jogadores_para_torneio(2)
        self.assertEqual(self.sortear().status_code, 200)

        partida = Partida.objects.get(torneio=self.torneio)
        participante = PartidaParticipante.objects.filter(
            partida=partida
        ).first()

        self.client.force_login(self.organizador)
        resposta = self.client.put(
            f"/api/partidas/resultado/{partida.id}/",
            {"vencedor_id": participante.jogador_id, "confirmado": True},
            content_type="application/json"
        )
        self.assertEqual(resposta.status_code, 403)

    def test_11_juiz_registra_resultado(self):
        self.criar_jogadores_para_torneio(2)
        self.assertEqual(self.sortear().status_code, 200)

        vencedores = self.registrar_vitorias_da_fase("Final")
        self.assertEqual(len(vencedores), 1)
        self.assertTrue(
            PartidaParticipante.objects.filter(
                jogador_id=vencedores[0], vitoria=True
            ).exists()
        )

    def test_12_consultar_classificacao(self):
        resposta = self.client.get(
            f"/api/torneios/classificacao/{self.torneio.id}/"
        )
        self.assertEqual(resposta.status_code, 200)
        self.assertIn("classificacao", resposta.json())

    def test_13_sortear_oito_jogadores(self):
        self.criar_jogadores_para_torneio(8)
        resposta = self.sortear()

        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(
            Partida.objects.filter(
                torneio=self.torneio, fase="Quartas de final"
            ).count(), 4
        )
        self.assertEqual(
            PartidaParticipante.objects.filter(
                partida__torneio=self.torneio
            ).count(), 8
        )

    def test_14_impedir_sorteio_duplicado(self):
        self.criar_jogadores_para_torneio(4)
        primeira = self.sortear()
        segunda = self.sortear()

        self.assertEqual(primeira.status_code, 200)
        self.assertEqual(segunda.status_code, 400)
        self.assertEqual(
            Partida.objects.filter(torneio=self.torneio).count(), 2
        )

    def test_15_nao_avancar_sem_resultados(self):
        self.criar_jogadores_para_torneio(8)
        self.assertEqual(self.sortear().status_code, 200)
        resposta = self.avancar()

        self.assertEqual(resposta.status_code, 400)
        self.assertFalse(
            Partida.objects.filter(
                torneio=self.torneio, fase="Semifinal"
            ).exists()
        )

    def test_16_avancar_quartas_para_semifinal(self):
        self.criar_jogadores_para_torneio(8)
        self.assertEqual(self.sortear().status_code, 200)

        vencedores = self.registrar_vitorias_da_fase("Quartas de final")
        resposta = self.avancar()

        self.assertEqual(resposta.status_code, 200)
        semifinais = Partida.objects.filter(
            torneio=self.torneio, fase="Semifinal"
        )
        self.assertEqual(semifinais.count(), 2)

        participantes = set(
            PartidaParticipante.objects.filter(
                partida__in=semifinais
            ).values_list("jogador_id", flat=True)
        )
        self.assertEqual(participantes, set(vencedores))

    def test_17_campeonato_completo_oito_jogadores(self):
        self.criar_jogadores_para_torneio(8)
        self.assertEqual(self.sortear().status_code, 200)

        self.registrar_vitorias_da_fase("Quartas de final")
        self.assertEqual(self.avancar().status_code, 200)

        self.registrar_vitorias_da_fase("Semifinal")
        self.assertEqual(self.avancar().status_code, 200)

        vencedores = self.registrar_vitorias_da_fase("Final")
        self.assertEqual(
            Partida.objects.filter(torneio=self.torneio).count(), 7
        )

        resposta = self.client.get(
            f"/api/torneios/classificacao/{self.torneio.id}/"
        )
        self.assertEqual(resposta.status_code, 200)

        classificacao = resposta.json()["classificacao"]
        self.assertEqual(classificacao[0]["id"], vencedores[0])
        self.assertEqual(classificacao[0]["vitorias"], 3)

    def test_18_impedir_avanco_duplicado(self):
        self.criar_jogadores_para_torneio(4)
        self.assertEqual(self.sortear().status_code, 200)
        self.registrar_vitorias_da_fase("Semifinal")

        primeira = self.avancar()
        segunda = self.avancar()

        self.assertEqual(primeira.status_code, 200)
        self.assertEqual(segunda.status_code, 400)
        self.assertEqual(
            Partida.objects.filter(
                torneio=self.torneio, fase="Final"
            ).count(), 1
        )

    def test_19_impedir_resultado_duplicado(self):
        self.criar_jogadores_para_torneio(4)
        self.assertEqual(self.sortear().status_code, 200)

        partida = Partida.objects.filter(torneio=self.torneio).first()
        participante = PartidaParticipante.objects.filter(
            partida=partida
        ).first()

        self.client.force_login(self.juiz)
        dados = {
            "vencedor_id": participante.jogador_id,
            "confirmado": True
        }

        primeira = self.client.put(
            f"/api/partidas/resultado/{partida.id}/",
            dados, content_type="application/json"
        )
        segunda = self.client.put(
            f"/api/partidas/resultado/{partida.id}/",
            dados, content_type="application/json"
        )

        self.assertEqual(primeira.status_code, 200)
        self.assertEqual(segunda.status_code, 400)

    def test_20_gerar_final_rota_antiga(self):
        self.criar_jogadores_para_torneio(4)
        self.assertEqual(self.sortear().status_code, 200)
        self.registrar_vitorias_da_fase("Semifinal")

        self.client.force_login(self.organizador)
        resposta = self.client.post(
            "/api/partidas/gerar-final/",
            {"torneio_id": self.torneio.id},
            content_type="application/json"
        )

        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(
            Partida.objects.filter(
                torneio=self.torneio, fase="Final"
            ).count(), 1
        )

    def test_21_criar_partida_manual(self):
        jogadores = self.criar_jogadores_para_torneio(4)
        resposta = self.criar_partida_manual(
            jogadores[0], jogadores[1], "Semifinal"
        )
        self.assertEqual(
            resposta.status_code, 200, resposta.content.decode()
        )
        self.assertEqual(
            Partida.objects.filter(torneio=self.torneio).count(), 1
        )

    def test_22_impedir_mesmo_jogador(self):
        jogadores = self.criar_jogadores_para_torneio(4)
        resposta = self.criar_partida_manual(
            jogadores[0], jogadores[0], "Semifinal"
        )
        self.assertEqual(resposta.status_code, 400)

    def test_23_impedir_partida_duplicada(self):
        jogadores = self.criar_jogadores_para_torneio(4)
        primeira = self.criar_partida_manual(
            jogadores[0], jogadores[1], "Semifinal"
        )
        segunda = self.criar_partida_manual(
            jogadores[1], jogadores[0], "Semifinal"
        )
        self.assertEqual(primeira.status_code, 200)
        self.assertEqual(segunda.status_code, 400)

    def test_24_impedir_jogador_em_duas_partidas(self):
        jogadores = self.criar_jogadores_para_torneio(4)
        primeira = self.criar_partida_manual(
            jogadores[0], jogadores[1], "Semifinal"
        )
        segunda = self.criar_partida_manual(
            jogadores[0], jogadores[2], "Semifinal"
        )
        self.assertEqual(primeira.status_code, 200)
        self.assertEqual(segunda.status_code, 400)

    def test_25_impedir_jogador_nao_inscrito(self):
        jogadores = self.criar_jogadores_para_torneio(4)
        visitante = Jogadores.objects.create(
            nome="Visitante",
            nick="Visitante",
            email="visitante@teste.com"
        )
        resposta = self.criar_partida_manual(
            jogadores[0], visitante, "Semifinal"
        )
        self.assertEqual(resposta.status_code, 400)

    def test_26_impedir_fase_invalida(self):
        jogadores = self.criar_jogadores_para_torneio(4)
        resposta = self.criar_partida_manual(
            jogadores[0], jogadores[1], "Fase Inventada"
        )
        self.assertEqual(resposta.status_code, 400)

    def test_27_impedir_pular_para_final(self):
        jogadores = self.criar_jogadores_para_torneio(4)
        resposta = self.criar_partida_manual(
            jogadores[0], jogadores[1], "Final"
        )
        self.assertEqual(resposta.status_code, 400)

    def test_28_classificacao_inicial(self):
        self.criar_jogadores_para_torneio(4)
        resposta = self.client.get(
            f"/api/torneios/classificacao/{self.torneio.id}/"
        )
        self.assertEqual(resposta.status_code, 200)

        classificacao = resposta.json()["classificacao"]
        self.assertEqual(len(classificacao), 4)

        for jogador in classificacao:
            self.assertEqual(jogador["vitorias"], 0)
            self.assertEqual(jogador["derrotas"], 0)
            self.assertEqual(jogador["partidas_disputadas"], 0)
            self.assertIsNone(jogador["posicao"])

    def test_29_classificacao_campeao_e_vice(self):
        self.criar_jogadores_para_torneio(4)
        self.assertEqual(self.sortear().status_code, 200)
        self.registrar_vitorias_da_fase("Semifinal")
        self.assertEqual(self.avancar().status_code, 200)

        vencedor_final = self.registrar_vitorias_da_fase("Final")[0]
        resposta = self.client.get(
            f"/api/torneios/classificacao/{self.torneio.id}/"
        )
        self.assertEqual(resposta.status_code, 200)

        classificacao = resposta.json()["classificacao"]
        campeao = classificacao[0]
        vice = classificacao[1]

        self.assertEqual(campeao["id"], vencedor_final)
        self.assertEqual(campeao["posicao"], 1)
        self.assertTrue(campeao["campeao"])
        self.assertEqual(campeao["vitorias"], 2)

        self.assertEqual(vice["posicao"], 2)
        self.assertFalse(vice["campeao"])
        self.assertEqual(vice["vitorias"], 1)

        terceiros = [
            jogador for jogador in classificacao
            if jogador["posicao"] == 3
        ]
        self.assertEqual(len(terceiros), 2)

    def test_30_classificacao_campeonato_oito_jogadores(self):
        self.criar_jogadores_para_torneio(8)
        self.assertEqual(self.sortear().status_code, 200)

        self.registrar_vitorias_da_fase("Quartas de final")
        self.assertEqual(self.avancar().status_code, 200)

        self.registrar_vitorias_da_fase("Semifinal")
        self.assertEqual(self.avancar().status_code, 200)

        vencedor_final = self.registrar_vitorias_da_fase("Final")[0]
        resposta = self.client.get(
            f"/api/torneios/classificacao/{self.torneio.id}/"
        )
        self.assertEqual(resposta.status_code, 200)

        classificacao = resposta.json()["classificacao"]
        self.assertEqual(len(classificacao), 8)
        self.assertEqual(classificacao[0]["id"], vencedor_final)

        posicoes = [jogador["posicao"] for jogador in classificacao]
        self.assertEqual(posicoes, [1, 2, 3, 3, 5, 5, 5, 5])
        self.assertEqual(classificacao[0]["vitorias"], 3)
