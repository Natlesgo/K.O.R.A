
import json
import random
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User, Group
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.db import transaction
from django.http import JsonResponse
from django.middleware.csrf import get_token
from .models import Torneio, Jogadores, Usuarios, TorneioJogadores, Partida, PartidaParticipante
from .forms import TorneioForm, JogadorForm, PartidaForm


def ler_json(request):
    try:
        dados = json.loads(request.body)
        if isinstance(dados, dict):
            return dados
        return None
    except (ValueError, UnicodeDecodeError):
        return None


def erro(mensagem, status=400):
    return JsonResponse({"erro": mensagem}, status=status)


def verificar_permissao(request, papel):
    if not request.user.is_authenticated:
        return erro("Usuario precisa estar logado", 401)

    if not request.user.groups.filter(name=papel).exists():
        return erro("Usuario nao possui permissao", 403)

    return None


def obter_organizador(request):
    return Usuarios.objects.filter(login=request.user.username).first()


def obter_torneio(torneio_id):
    if type(torneio_id) is not int or torneio_id <= 0:
        return None

    return Torneio.objects.filter(id=torneio_id).first()


def obter_csrf(request):
    if request.method != "GET":
        return erro("Metodo nao permitido", 405)

    return JsonResponse({"csrfToken": get_token(request)})


def login_usuario(request):
    if request.method != "POST":
        return erro("Metodo nao permitido", 405)

    dados = ler_json(request)

    if dados is None:
        return erro("JSON invalido")

    username = dados.get("login")
    senha = dados.get("senha")

    if not isinstance(username, str) or not isinstance(senha, str):
        return erro("Preencha o login e a senha")

    if not username or not senha:
        return erro("Preencha o login e a senha")

    usuario = authenticate(request, username=username, password=senha)

    if usuario is None:
        return erro("Login ou senha incorretos", 401)

    login(request, usuario)
    grupos = list(usuario.groups.values_list("name", flat=True))

    return JsonResponse({
        "mensagem": "Login realizado com sucesso",
        "usuario": usuario.username,
        "grupos": grupos,
        "csrfToken": get_token(request)
    })


def logout_usuario(request):
    if request.method != "POST":
        return erro("Metodo nao permitido", 405)

    logout(request)

    return JsonResponse({"mensagem": "Logout realizado com sucesso"})


def consultar_usuario(request):
    if request.method != "GET":
        return erro("Metodo nao permitido", 405)

    if not request.user.is_authenticated:
        return erro("Usuario precisa estar logado", 401)

    grupos = list(request.user.groups.values_list("name", flat=True))

    return JsonResponse({
        "usuario": request.user.username,
        "grupos": grupos
    })


def listar_torneios(request):
    if request.method != "GET":
        return erro("Metodo nao permitido", 405)

    lista = []

    for torneio in Torneio.objects.all():
        lista.append({
            "id": torneio.id,
            "nome": torneio.nome,
            "codigo": torneio.codigo
        })

    return JsonResponse({"torneios": lista})


def cadastrar_torneio(request):
    if request.method != "POST":
        return erro("Metodo nao permitido", 405)

    permissao = verificar_permissao(request, "organizador")

    if permissao is not None:
        return permissao

    dados = ler_json(request)

    if dados is None:
        return erro("JSON invalido")

    nome = dados.get("nome")
    codigo = dados.get("codigo")

    if not isinstance(nome, str) or not isinstance(codigo, str):
        return erro("Nome e codigo invalidos")

    nome = nome.strip()
    codigo = codigo.strip()

    if not nome or not codigo:
        return erro("Preencha o nome e o codigo")

    if len(nome) > 45 or len(codigo) > 45:
        return erro("Nome ou codigo muito longo")

    form = TorneioForm({"nome": nome, "codigo": codigo})

    if not form.is_valid():
        return erro("Dados do torneio invalidos")

    if Torneio.objects.filter(codigo=codigo).exists():
        return erro("Codigo de torneio ja cadastrado")

    torneio = Torneio.objects.create(
        nome=form.cleaned_data["nome"],
        codigo=form.cleaned_data["codigo"]
    )

    return JsonResponse({
        "mensagem": "Torneio cadastrado com sucesso",
        "id": torneio.id
    })


def atualizar_torneio(request, torneio_id):
    if request.method != "PUT":
        return erro("Metodo nao permitido", 405)

    permissao = verificar_permissao(request, "organizador")

    if permissao is not None:
        return permissao

    dados = ler_json(request)

    if dados is None:
        return erro("JSON invalido")

    nome = dados.get("nome")
    codigo = dados.get("codigo")

    if not isinstance(nome, str) or not isinstance(codigo, str):
        return erro("Nome e codigo invalidos")

    nome = nome.strip()
    codigo = codigo.strip()

    if not nome or not codigo:
        return erro("Preencha o nome e o codigo")

    if len(nome) > 45 or len(codigo) > 45:
        return erro("Nome ou codigo muito longo")

    form = TorneioForm({"nome": nome, "codigo": codigo})

    if not form.is_valid():
        return erro("Dados do torneio invalidos")

    torneio = Torneio.objects.filter(id=torneio_id).first()

    if torneio is None:
        return erro("Torneio nao encontrado", 404)

    if Torneio.objects.filter(codigo=codigo).exclude(id=torneio_id).exists():
        return erro("Codigo de torneio ja cadastrado")

    torneio.nome = form.cleaned_data["nome"]
    torneio.codigo = form.cleaned_data["codigo"]
    torneio.save()

    return JsonResponse({"mensagem": "Torneio atualizado com sucesso"})


def cadastrar_jogador(request):
    if request.method != "POST":
        return erro("Metodo nao permitido", 405)

    dados = ler_json(request)

    if dados is None:
        return erro("JSON invalido")

    nome = dados.get("nome")
    nick = dados.get("nick")
    email = dados.get("email")
    senha = dados.get("senha")

    valores = (nome, nick, email, senha)

    for valor in valores:
        if not isinstance(valor, str) or not valor.strip():
            return erro("Informe nome, nick, email e senha")

    nome = nome.strip()
    nick = nick.strip()
    email = email.strip().lower()

    if len(nome) > 45 or len(nick) > 45 or len(email) > 45:
        return erro("Nome, nick ou email muito longo")

    if "@" not in email:
        return erro("Email invalido")

    form = JogadorForm({
        "nome": nome,
        "nick": nick,
        "email": email,
        "senha": senha
    })

    if not form.is_valid():
        return erro("Dados do jogador invalidos")

    if Jogadores.objects.filter(email__iexact=email).exists():
        return erro("Email ja cadastrado")

    if User.objects.filter(username__iexact=email).exists():
        return erro("Email ja cadastrado")

    if User.objects.filter(email__iexact=email).exists():
        return erro("Email ja cadastrado")

    try:
        validate_password(senha)
    except ValidationError as exc:
        return JsonResponse({
            "erro": "Senha invalida",
            "detalhes": exc.messages
        }, status=400)

    with transaction.atomic():
        conta = User.objects.create_user(
            username=form.cleaned_data["email"],
            email=form.cleaned_data["email"],
            password=senha
        )

        grupo, criado = Group.objects.get_or_create(name="jogador")
        conta.groups.add(grupo)

        jogador = Jogadores.objects.create(
            nome=form.cleaned_data["nome"],
            nick=form.cleaned_data["nick"],
            email=form.cleaned_data["email"]
        )

    return JsonResponse({
        "mensagem": "Jogador cadastrado com sucesso",
        "id": jogador.id,
        "login": email
    }, status=201)


def consultar_meu_jogador(request):
    if request.method != "GET":
        return erro("Metodo nao permitido", 405)

    permissao = verificar_permissao(request, "jogador")

    if permissao is not None:
        return permissao

    try:
        jogador = Jogadores.objects.get(email__iexact=request.user.email)
    except Jogadores.DoesNotExist:
        return erro("Cadastro do jogador nao encontrado", 404)
    except Jogadores.MultipleObjectsReturned:
        return erro("Cadastro duplicado", 409)

    return JsonResponse({
        "id": jogador.id,
        "nome": jogador.nome,
        "nick": jogador.nick,
        "email": jogador.email
    })


def inscrever_jogador(request):
    if request.method != "POST":
        return erro("Metodo nao permitido", 405)

    permissao = verificar_permissao(request, "jogador")

    if permissao is not None:
        return permissao

    dados = ler_json(request)

    if dados is None:
        return erro("JSON invalido")

    torneio_id = dados.get("torneio_id")

    if type(torneio_id) is not int or torneio_id <= 0:
        return erro("Informe um torneio_id valido")

    torneio = obter_torneio(torneio_id)

    if torneio is None:
        return erro("Torneio nao encontrado", 404)

    try:
        jogador = Jogadores.objects.get(email__iexact=request.user.email)
    except Jogadores.DoesNotExist:
        return erro("Cadastro do jogador nao encontrado", 404)
    except Jogadores.MultipleObjectsReturned:
        return erro("Cadastro duplicado", 409)

    if TorneioJogadores.objects.filter(torneio=torneio, jogador=jogador).exists():
        return erro("Jogador ja inscrito nesse torneio")

    if Partida.objects.filter(torneio=torneio).exists():
        return erro("As inscricoes deste torneio foram encerradas")

    inscricao = TorneioJogadores.objects.create(
        torneio=torneio,
        jogador=jogador
    )

    return JsonResponse({
        "mensagem": "Inscricao realizada com sucesso",
        "id": inscricao.id
    })


def listar_inscricoes(request, torneio_id):
    if request.method != "GET":
        return erro("Metodo nao permitido", 405)

    torneio = Torneio.objects.filter(id=torneio_id).first()

    if torneio is None:
        return erro("Torneio nao encontrado", 404)

    lista = []
    inscricoes = TorneioJogadores.objects.filter(torneio=torneio).select_related("jogador")

    for inscricao in inscricoes:
        lista.append({
            "id": inscricao.jogador.id,
            "nome": inscricao.jogador.nome,
            "nick": inscricao.jogador.nick
        })

    return JsonResponse({
        "torneio": torneio.nome,
        "jogadores": lista
    })


def nome_fase_por_jogadores(quantidade):
    fases = {
        2: "Final",
        4: "Semifinal",
        8: "Quartas de final"
    }

    return fases.get(quantidade)


def criar_confrontos(torneio, usuario, jogadores, fase):
    confrontos = []

    for i in range(0, len(jogadores), 2):
        jogador1 = jogadores[i]
        jogador2 = jogadores[i + 1]

        partida = Partida.objects.create(
            fase=fase,
            torneio=torneio,
            usuario=usuario
        )

        PartidaParticipante.objects.create(
            torneio=torneio,
            jogador=jogador1,
            partida=partida,
            vitoria=False
        )

        PartidaParticipante.objects.create(
            torneio=torneio,
            jogador=jogador2,
            partida=partida,
            vitoria=False
        )

        confrontos.append({
            "partida_id": partida.id,
            "fase": fase,
            "jogador1": jogador1.nick,
            "jogador2": jogador2.nick
        })

    return confrontos


def sortear_confrontos(request):
    if request.method != "POST":
        return erro("Metodo nao permitido", 405)

    permissao = verificar_permissao(request, "organizador")

    if permissao is not None:
        return permissao

    dados = ler_json(request)

    if dados is None:
        return erro("JSON invalido")

    torneio = obter_torneio(dados.get("torneio_id"))

    if torneio is None:
        return erro("Torneio nao encontrado ou ID invalido", 404)

    usuario = obter_organizador(request)

    if usuario is None:
        return erro("Usuario organizador nao encontrado", 404)

    inscricoes = TorneioJogadores.objects.filter(
        torneio=torneio
    ).values_list("jogador_id", flat=True)

    jogadores = list(Jogadores.objects.filter(id__in=inscricoes).distinct())

    fase_esperada = nome_fase_por_jogadores(len(jogadores))

    if fase_esperada is None:
        return erro("O torneio deve ter 2, 4 ou 8 jogadores para o chaveamento automatico")

    fase_informada = dados.get("fase")

    if fase_informada is not None and fase_informada != fase_esperada:
        return erro("Fase inicial invalida. Utilize: " + fase_esperada)

    with transaction.atomic():
        torneio = Torneio.objects.select_for_update().get(id=torneio.id)

        if Partida.objects.filter(torneio=torneio).exists():
            return erro("O torneio ja possui partidas cadastradas")

        random.shuffle(jogadores)

        confrontos = criar_confrontos(
            torneio, usuario, jogadores, fase_esperada
        )

    return JsonResponse({
        "mensagem": "Confrontos sorteados com sucesso",
        "torneio": torneio.nome,
        "total_partidas": len(confrontos),
        "confrontos": confrontos
    })


def avancar_fase(request):
    if request.method != "POST":
        return erro("Metodo nao permitido", 405)

    permissao = verificar_permissao(request, "organizador")

    if permissao is not None:
        return permissao

    dados = ler_json(request)

    if dados is None:
        return erro("JSON invalido")

    torneio = obter_torneio(dados.get("torneio_id"))

    if torneio is None:
        return erro("Torneio nao encontrado ou ID invalido", 404)

    usuario = obter_organizador(request)

    if usuario is None:
        return erro("Usuario organizador nao encontrado", 404)

    fases = ["Quartas de final", "Semifinal", "Final"]

    with transaction.atomic():
        torneio = Torneio.objects.select_for_update().get(id=torneio.id)
        partidas = list(Partida.objects.filter(torneio=torneio).order_by("id"))

        if not partidas:
            return erro("Sorteie os confrontos antes de avancar")

        fases_presentes = set()

        for partida in partidas:
            fases_presentes.add(partida.fase)

        for fase in fases_presentes:
            if fase not in fases:
                return erro("Existem partidas com fases nao reconhecidas")

        fase_atual = max(fases_presentes, key=fases.index)

        if fase_atual == "Final":
            return erro("O torneio ja chegou a final")

        partidas_atuais = []

        for partida in partidas:
            if partida.fase == fase_atual:
                partidas_atuais.append(partida)

        if fase_atual == "Quartas de final":
            quantidade_esperada = 4
        else:
            quantidade_esperada = 2

        if len(partidas_atuais) != quantidade_esperada:
            return erro("Quantidade de partidas invalida na fase atual")

        proxima_fase = fases[fases.index(fase_atual) + 1]

        for partida in partidas:
            if partida.fase == proxima_fase:
                return erro("A proxima fase ja foi criada")

        vencedores = []

        for partida in partidas_atuais:
            participantes = list(
                PartidaParticipante.objects.filter(
                    partida=partida
                ).select_related("jogador")
            )

            if len(participantes) != 2:
                return erro("Uma partida possui participantes invalidos")

            if participantes[0].jogador_id == participantes[1].jogador_id:
                return erro("Uma partida possui jogadores repetidos")

            ganhadores = []

            for participante in participantes:
                if participante.vitoria:
                    ganhadores.append(participante.jogador)

            if len(ganhadores) != 1:
                return erro("Todas as partidas da fase precisam ter um vencedor")

            vencedores.append(ganhadores[0])

        ids_vencedores = []

        for jogador in vencedores:
            ids_vencedores.append(jogador.id)

        if len(set(ids_vencedores)) != len(ids_vencedores):
            return erro("Um jogador nao pode vencer duas partidas na mesma fase")

        confrontos = criar_confrontos(
            torneio, usuario, vencedores, proxima_fase
        )

    return JsonResponse({
        "mensagem": "Proxima fase criada com sucesso",
        "torneio": torneio.nome,
        "fase": proxima_fase,
        "total_partidas": len(confrontos),
        "confrontos": confrontos
    })


def gerar_final(request):
    if request.method != "POST":
        return erro("Metodo nao permitido", 405)

    permissao = verificar_permissao(request, "organizador")

    if permissao is not None:
        return permissao

    dados = ler_json(request)

    if dados is None:
        return erro("JSON invalido")

    torneio = obter_torneio(dados.get("torneio_id"))

    if torneio is None:
        return erro("Torneio nao encontrado ou ID invalido", 404)

    if Partida.objects.filter(torneio=torneio, fase="Final").exists():
        return erro("A final ja foi criada")

    if Partida.objects.filter(torneio=torneio, fase="Semifinal").count() != 2:
        return erro("O torneio precisa possuir duas semifinais")

    resposta = avancar_fase(request)

    if resposta.status_code != 200:
        return resposta

    resultado = json.loads(resposta.content)

    if resultado["fase"] != "Final":
        return erro("Nao foi possivel gerar a final")

    confronto = resultado["confrontos"][0]

    return JsonResponse({
        "mensagem": "Final criada com sucesso",
        "partida_id": confronto["partida_id"],
        "jogador1": confronto["jogador1"],
        "jogador2": confronto["jogador2"]
    })


def criar_partida(request):
    if request.method != "POST":
        return erro("Metodo nao permitido", 405)

    permissao = verificar_permissao(request, "organizador")

    if permissao is not None:
        return permissao

    dados = ler_json(request)

    if dados is None:
        return erro("JSON invalido")

    torneio_id = dados.get("torneio_id")
    jogador1_id = dados.get("jogador1_id")
    jogador2_id = dados.get("jogador2_id")
    fase = dados.get("fase")

    if not isinstance(fase, str) or not fase.strip():
        return erro("Informe a fase da partida")

    fase = fase.strip()
    fases = ["Quartas de final", "Semifinal", "Final"]

    if fase not in fases:
        return erro("Fase invalida. Use Quartas de final, Semifinal ou Final")

    ids = [torneio_id, jogador1_id, jogador2_id]

    for valor in ids:
        if type(valor) is not int or valor <= 0:
            return erro("IDs invalidos")

    if jogador1_id == jogador2_id:
        return erro("Os jogadores devem ser diferentes")

    form = PartidaForm({
        "torneio_id": torneio_id,
        "jogador1_id": jogador1_id,
        "jogador2_id": jogador2_id,
        "fase": fase
    })

    if not form.is_valid():
        return erro("Dados da partida invalidos")

    torneio = obter_torneio(torneio_id)

    if torneio is None:
        return erro("Torneio nao encontrado", 404)

    usuario = obter_organizador(request)

    if usuario is None:
        return erro("Usuario nao encontrado", 404)

    jogadores = list(
        Jogadores.objects.filter(id__in=[jogador1_id, jogador2_id])
    )

    if len(jogadores) != 2:
        return erro("Jogador nao encontrado", 404)

    with transaction.atomic():
        torneio = Torneio.objects.select_for_update().get(id=torneio.id)

        inscritos = set(
            TorneioJogadores.objects.filter(
                torneio=torneio,
                jogador_id__in=[jogador1_id, jogador2_id]
            ).values_list("jogador_id", flat=True)
        )

        if jogador1_id not in inscritos:
            return erro("Jogador 1 nao esta inscrito no torneio")

        if jogador2_id not in inscritos:
            return erro("Jogador 2 nao esta inscrito no torneio")

        partidas = list(Partida.objects.filter(torneio=torneio).order_by("id"))

        fases_existentes = set()

        for partida in partidas:
            fases_existentes.add(partida.fase)

        for fase_existente in fases_existentes:
            if fase_existente not in fases:
                return erro("Existem partidas com fases nao reconhecidas")

        if fases_existentes:
            fase_mais_avancada = max(fases_existentes, key=fases.index)

            if fase != fase_mais_avancada:
                return erro("Use o avanco automatico para mudar de fase")
        else:
            quantidade_inscritos = TorneioJogadores.objects.filter(
                torneio=torneio
            ).values("jogador_id").distinct().count()

            fase_inicial = nome_fase_por_jogadores(quantidade_inscritos)

            if fase_inicial is None:
                return erro("O torneio deve ter 2, 4 ou 8 jogadores")

            if fase != fase_inicial:
                return erro("Fase inicial invalida. Utilize: " + fase_inicial)

        partidas_da_fase = []

        for partida in partidas:
            if partida.fase == fase:
                partidas_da_fase.append(partida)

        limites = {
            "Quartas de final": 4,
            "Semifinal": 2,
            "Final": 1
        }

        if len(partidas_da_fase) >= limites[fase]:
            return erro("A fase ja possui todas as partidas")

        ids_na_fase = list(
            PartidaParticipante.objects.filter(
                partida__torneio=torneio,
                partida__fase=fase
            ).values_list("jogador_id", flat=True)
        )

        if jogador1_id in ids_na_fase or jogador2_id in ids_na_fase:
            return erro("Um dos jogadores ja possui partida nesta fase")

        indice_fase = fases.index(fase)

        if indice_fase > 0:
            fase_anterior = fases[indice_fase - 1]

            partidas_anteriores = Partida.objects.filter(
                torneio=torneio,
                fase=fase_anterior
            )

            if partidas_anteriores.exists():
                vencedores = set(
                    PartidaParticipante.objects.filter(
                        partida__in=partidas_anteriores,
                        vitoria=True
                    ).values_list("jogador_id", flat=True)
                )

                if jogador1_id not in vencedores or jogador2_id not in vencedores:
                    return erro("Somente vencedores da fase anterior podem avancar")

        partida = Partida.objects.create(
            fase=form.cleaned_data["fase"],
            torneio=torneio,
            usuario=usuario
        )

        PartidaParticipante.objects.create(
            torneio=torneio,
            jogador_id=jogador1_id,
            partida=partida,
            vitoria=False
        )

        PartidaParticipante.objects.create(
            torneio=torneio,
            jogador_id=jogador2_id,
            partida=partida,
            vitoria=False
        )

    return JsonResponse({
        "mensagem": "Partida criada com sucesso",
        "id": partida.id
    })


def listar_partidas(request, torneio_id):
    if request.method != "GET":
        return erro("Metodo nao permitido", 405)

    torneio = Torneio.objects.filter(id=torneio_id).first()

    if torneio is None:
        return erro("Torneio nao encontrado", 404)

    lista = []
    partidas = Partida.objects.filter(torneio=torneio).order_by("id")

    for partida in partidas:
        participantes = PartidaParticipante.objects.filter(
            partida=partida
        ).select_related("jogador")

        jogadores = []
        vencedor = None

        for participante in participantes:
            jogadores.append({
                "id": participante.jogador.id,
                "nick": participante.jogador.nick,
                "vitoria": participante.vitoria
            })

            if participante.vitoria:
                vencedor = participante.jogador.nick

        lista.append({
            "id": partida.id,
            "fase": partida.fase,
            "jogadores": jogadores,
            "vencedor": vencedor
        })

    return JsonResponse({
        "torneio": torneio.nome,
        "partidas": lista
    })


def consultar_partida(request, partida_id):
    if request.method != "GET":
        return erro("Metodo nao permitido", 405)

    partida = Partida.objects.filter(id=partida_id).first()

    if partida is None:
        return erro("Partida nao encontrada", 404)

    participantes = PartidaParticipante.objects.filter(
        partida=partida
    ).select_related("jogador")

    jogadores = []
    vencedor = None

    for participante in participantes:
        jogadores.append({
            "id": participante.jogador.id,
            "nick": participante.jogador.nick,
            "vitoria": participante.vitoria
        })

        if participante.vitoria:
            vencedor = participante.jogador.nick

    return JsonResponse({
        "id": partida.id,
        "fase": partida.fase,
        "torneio": partida.torneio.nome,
        "jogadores": jogadores,
        "vencedor": vencedor
    })


def registrar_resultado(request, partida_id):
    if request.method != "PUT":
        return erro("Metodo nao permitido", 405)

    permissao = verificar_permissao(request, "juiz")

    if permissao is not None:
        return permissao

    dados = ler_json(request)

    if dados is None:
        return erro("JSON invalido")

    vencedor_id = dados.get("vencedor_id")
    confirmado = dados.get("confirmado")

    if type(vencedor_id) is not int or vencedor_id <= 0:
        return erro("Informe o jogador vencedor")

    if confirmado is not True:
        return erro("O resultado precisa ser confirmado pelo juiz")

    with transaction.atomic():
        partida = Partida.objects.select_for_update().filter(
            id=partida_id
        ).first()

        if partida is None:
            return erro("Partida nao encontrada", 404)

        participantes = list(
            PartidaParticipante.objects.filter(partida=partida)
        )

        if len(participantes) != 2:
            return erro("A partida deve possuir dois jogadores")

        if participantes[0].jogador_id == participantes[1].jogador_id:
            return erro("A partida possui jogadores repetidos")

        ids = []

        for participante in participantes:
            ids.append(participante.jogador_id)

        if vencedor_id not in ids:
            return erro("O vencedor nao participou da partida")

        for participante in participantes:
            if participante.vitoria:
                return erro("A partida ja possui um resultado")

        for participante in participantes:
            participante.vitoria = participante.jogador_id == vencedor_id
            participante.save()

    return JsonResponse({
        "mensagem": "Resultado registrado com sucesso",
        "partida_id": partida_id,
        "vencedor_id": vencedor_id
    })


def consultar_torneio(request, torneio_id):
    if request.method != "GET":
        return erro("Metodo nao permitido", 405)

    torneio = Torneio.objects.filter(id=torneio_id).first()

    if torneio is None:
        return erro("Torneio nao encontrado", 404)

    jogadores = []
    inscricoes = TorneioJogadores.objects.filter(
        torneio=torneio
    ).select_related("jogador")

    for inscricao in inscricoes:
        jogadores.append({
            "id": inscricao.jogador.id,
            "nome": inscricao.jogador.nome,
            "nick": inscricao.jogador.nick
        })

    lista_partidas = []
    partidas = Partida.objects.filter(torneio=torneio).order_by("id")

    for partida in partidas:
        participantes = PartidaParticipante.objects.filter(
            partida=partida
        ).select_related("jogador")

        lista_participantes = []
        vencedor = None

        for participante in participantes:
            lista_participantes.append({
                "id": participante.jogador.id,
                "nick": participante.jogador.nick,
                "vitoria": participante.vitoria
            })

            if participante.vitoria:
                vencedor = participante.jogador.nick

        lista_partidas.append({
            "id": partida.id,
            "fase": partida.fase,
            "jogadores": lista_participantes,
            "vencedor": vencedor
        })

    return JsonResponse({
        "id": torneio.id,
        "nome": torneio.nome,
        "codigo": torneio.codigo,
        "total_jogadores": len(jogadores),
        "total_partidas": len(lista_partidas),
        "jogadores": jogadores,
        "partidas": lista_partidas
    })


def consultar_classificacao(request, torneio_id):
    if request.method != "GET":
        return erro("Metodo nao permitido", 405)

    torneio = Torneio.objects.filter(id=torneio_id).first()

    if torneio is None:
        return erro("Torneio nao encontrado", 404)

    inscricoes = TorneioJogadores.objects.filter(
        torneio=torneio
    ).select_related("jogador")

    participacoes = list(
        PartidaParticipante.objects.filter(
            partida__torneio=torneio
        ).select_related("partida", "jogador")
    )

    vencedores = {}

    for participacao in participacoes:
        if participacao.vitoria:
            vencedores[participacao.partida_id] = participacao.jogador_id

    ordem_fases = {
        "Quartas de final": 1,
        "Semifinal": 2,
        "Final": 3
    }

    posicoes_eliminacao = {
        "Quartas de final": 5,
        "Semifinal": 3,
        "Final": 2
    }

    classificacao = []

    for inscricao in inscricoes:
        jogador = inscricao.jogador

        vitorias = 0
        derrotas = 0
        fase_alcancada = None
        maior_nivel = 0
        fase_eliminacao = None
        campeao = False

        for participacao in participacoes:
            if participacao.jogador_id != jogador.id:
                continue

            fase = participacao.partida.fase
            nivel = ordem_fases.get(fase, 0)

            if nivel > maior_nivel:
                maior_nivel = nivel
                fase_alcancada = fase

            vencedor_id = vencedores.get(participacao.partida_id)

            if vencedor_id is None:
                continue

            if vencedor_id == jogador.id:
                vitorias += 1

                if fase == "Final":
                    campeao = True
            else:
                derrotas += 1
                fase_eliminacao = fase

        if campeao:
            posicao = 1
        else:
            posicao = posicoes_eliminacao.get(fase_eliminacao)

        classificacao.append({
            "id": jogador.id,
            "nick": jogador.nick,
            "vitorias": vitorias,
            "derrotas": derrotas,
            "partidas_disputadas": vitorias + derrotas,
            "posicao": posicao,
            "campeao": campeao,
            "fase_alcancada": fase_alcancada
        })

    classificacao.sort(
        key=lambda jogador: (
            jogador["posicao"] is None,
            jogador["posicao"] if jogador["posicao"] is not None else 999,
            -ordem_fases.get(jogador["fase_alcancada"], 0),
            -jogador["vitorias"],
            jogador["nick"].lower()
        )
    )

    return JsonResponse({
        "torneio": torneio.nome,
        "classificacao": classificacao
    })
