from django.contrib import admin
from sistemas.models import Torneio
from sistemas.models import Jogadores
from sistemas.models import Usuarios
from sistemas.models import TorneioJogadores
from sistemas.models import Partida
from sistemas.models import PartidaParticipante

admin.site.register(Torneio)
admin.site.register(Jogadores)
admin.site.register(Usuarios)
admin.site.register(TorneioJogadores)
admin.site.register(Partida)
admin.site.register(PartidaParticipante)
